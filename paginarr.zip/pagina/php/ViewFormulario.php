<!DOCTYPE html>
<html>
<head>
	<title>Formulario</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="../css/pagina.css">
	<link rel="stylesheet" type="text/css" href="../css/librerias/DateTimePicker/css/jquery.datetimepicker.min.css">

	<!--Archivo JavaScript-->
	<script type="text/javascript" src = "../css/librerias/DateTimePicker/js/jquery.datetimepicker.full.min.js"></script>
		<script src="../js/paginaejemplo.js"></script>
<style type="text/css">
	body 
	{
		background-image: url("../imagenes/fondo.jpg");
		background-repeat: no-repeat;
		background-attachment: fixed;  
	  	background-size: 100% 100%;
	}
</style>
</head>
<body>
	<div>
		<ul>
			<li><a href="../index.html">Home</a></li>
			<li><a href="ViewProductos.php">Productos</a></li>
			<li><a class="active" href="ViewFormulario.php">Formulario</a></li>
		</ul>		
	</div>
	<br>
	<div class="container">
		<div  class="row">
				<div class="col-sm-12 text-center" style="background-color:#e60073;"><!--#e60073 los codigos hexadecimales con los colores de los apartados en la pagina para cambiarlos solo toma el codigo hexadecial de otro color y pegalo despues del # -->
					<h3>Ejemplos de Formulario</h3>
				</div>
				<div class="col-sm-12">
					<div class="row">
					    <div class="col-sm-6" style="background-color:#4898DA;" class="row" align="center">Datos personales</div>
					    <div class="col-sm-6" style="background-color:#2CD6B2;" align="center">Datos de un Auto</div>
					</div>
				</div>
		</div>
		
		<div class="row">			
			<div class="col-sm-6" class="container" style="background-color:#246182;" >
				<label>Nombre:</label><br>
				<input type="text" class="form-control" id="Nombre">
				
				<label>Apellido Paterno:</label><br>
				<input type="text" class="form-control" id="ApPaterno">
				
				<label>Apellido Materno:</label><br>
				<input type="text" class="form-control" id="ApMaterno">
				
				<label>Fecha De Nacimiento:</label><br>
				<input class="form-control date-picker" readonly="true" id="FechaNacimiento" type="text">

				<label>Direccion:</label><br>
				<input type="text" class="form-control" id="Direccion">
				
				<label>Telefono:</label><br>
				<input type="text" class="form-control" id="Telefono">
				
				<label>Estado Civil:</label><br>
				<input type="text" class="form-control" id="EsCivil">
				
				<label>CURP:</label><br>
				<input type="text" class="form-control" id="CURP">
				
				<label>RFC:</label><br>
				<input type="text" class="form-control" id="RFC">
				
				<label>NSS:</label><br>
				<input type="text" class="form-control" id="NSS">
				
				<label>Nivel De Estudio:</label><br>
				<input type="text" class="form-control" id="NivelEstudio">
				<br>

				<button type="button" class="btn btn-success" id="BtnGuardarpr">Enviar</button>

			</div>
			<div class="col-sm-6" class="container" style="background-color:#086C2D;">
				<label>Nombre:</label><br>
				<input type="text" class="form-control" id="Nombre">
				<label>Modelo:</label><br>
				<input type="text" class="form-control" id="Modelo">
				<label>Marca:</label><br>
				<input type="text" class="form-control" id="Marca">
				<label>Motor:</label><br>
				<input type="text" class="form-control" id="Motor">
				<label>Colores Disponibles:</label><br>
				<input type="text" class="form-control" id="ColoresDisp">
				<label>Costo:</label><br>
				<input type="text" class="form-control" id="Costo">
				<br>
				<label>Extras:</label>
				<br>
				<div class="container">
					<label class="form-check-label" for="Att">
		        		<input type="radio" class="form-check-input" id="Att" name="Pantalla" value="something"> Pantalla
		      		</label><br>
		      		<label class="form-check-label" for="Att">
		        		<input type="radio" class="form-check-input" id="Att" name="Rines" value="something"> Rines
		      		</label><br>
		      		<label class="form-check-label" for="Att">
		        		<input type="radio" class="form-check-input" id="Att" name="Aire" value="something"> Aire
		      		</label><br>
		      		<label class="form-check-label" for="Att">
		        		<input type="radio" class="form-check-input" id="Att" name="Seguro" value="something"> Seguro
		      		</label>
				</div>
				<br>
				
	      		<button type="button" class="btn btn-success" id="BtnGuardarau">Enviar</button>

			</div>
		</div>
	</div>
</body>
</html>