<?php 
	include('Conexiones.php');
	//include('../ConexionEnruter.php');

	/**
	 Aqui es la parte donde se hacen las consultas a base datos.
	 */
	class CGeneralConsultas
	{
		public static function GuardarDatosPersonales()
		{

		}
		public static function GuardarDatosAutomovil()
		{

		}
		public static function BuscarDatosPersonales()
		{
			$datos = new stdClass();
			$arrDatos = array();
			$conexion =  new PDO("mysql:host=".IP.";port=".PUERTO.";dbname=".BASEDEDATOS, USUARIO, PASSWORD!=null&&PASSWORD!=""?PASSWORD:"");
			if ($conexion) 
			{
				$cSql = "SELECT nombre,apellido_paterno,apellido_materno,fechanacimineto,direccion,telefono,estadocivil,curp,rfc,nss,nivelEstudio FROM datos_peroanles";
		
				$resultSet = $conexion->query($cSql);
				if ($resultSet) 
				{
					foreach ($resultSet as $resultado) 
					{	
						$arrDatos['nombre'][]           = $resultado['nombre'];
						$arrDatos['apellido_paterno'][] = $resultado['apellido_paterno'];
						$arrDatos['apellido_materno'][] = $resultado['apellido_materno'];
						$arrDatos['fechanacimineto'][]  = $resultado['fechanacimineto'];
						$arrDatos['direccion'][]        = $resultado['direccion'];
						$arrDatos['telefono'][]         = $resultado['telefono'];
						$arrDatos['estadocivil'][]      = $resultado['estadocivil'];
						$arrDatos['curp'][]             = $resultado['curp'];
						$arrDatos['rfc'][]              = $resultado['rfc']; 
						$arrDatos['nss'][]              = $resultado['nss'];
						$arrDatos['nivelEstudio'][]     = $resultado['nivelEstudio'];						
					}
				}
				$datos->datoscit = $arrDatos;
				$datos->codigoRespuesta = 1;
			}
			$conexion = null;		
			return $datos;
		}
		public static function EliminarDatosPersonales($nombre)
		{
			$datos = new stdClass();
			$arrDatos = array();
			$conexion =  new PDO("mysql:host=".IP.";port=".PUERTO.";dbname=".BASEDEDATOS, USUARIO, PASSWORD!=null&&PASSWORD!=""?PASSWORD:"");
			if ($conexion) 
			{
				$cSql = "DELETE FROM datos_peroanles WHERE nombre = '$nombre'";
		
				$resultSet = $conexion->query($cSql);
				if ($conexion) 
				{
					$datos->codigoRespuesta = 1;
					$datos->descripcion = "Hecho EliminarDatosPersonales()";
				}
				else
				{
					$datos->codigoRespuesta = 0;
					$datos->descripcion = "ALGO SALIO MAL fncalculosfinalespmg()";
				}
				return $datos;
				$cnxBd = null;	

			}
		}
		public static function EditarDatosPersonales($nombre)
		{
			$datos = new stdClass();
			$arrDatos = array();
			$conexion =  new PDO("mysql:host=".IP.";port=".PUERTO.";dbname=".BASEDEDATOS, USUARIO, PASSWORD!=null&&PASSWORD!=""?PASSWORD:"");
			if ($conexion) 
			{
				$cSql = "SELECT nombre,apellido_paterno,apellido_materno,fechanacimineto,direccion,telefono,estadocivil,curp,rfc,nss,nivelEstudio FROM datos_peroanles WHERE nombre = $nombre";
		
				$resultSet = $conexion->query($cSql);
				if ($resultSet) 
				{
					foreach ($resultSet as $resultado) 
					{	
						$arrDatos['nombre'][]           = $resultado['nombre'];
						$arrDatos['apellido_paterno'][] = $resultado['apellido_paterno'];
						$arrDatos['apellido_materno'][] = $resultado['apellido_materno'];
						$arrDatos['fechanacimineto'][]  = $resultado['fechanacimineto'];
						$arrDatos['direccion'][]        = $resultado['direccion'];
						$arrDatos['telefono'][]         = $resultado['telefono'];
						$arrDatos['estadocivil'][]      = $resultado['estadocivil'];
						$arrDatos['curp'][]             = $resultado['curp'];
						$arrDatos['rfc'][]              = $resultado['rfc']; 
						$arrDatos['nss'][]              = $resultado['nss'];
						$arrDatos['nivelEstudio'][]     = $resultado['nivelEstudio'];						
					}
				}
				$datos->datoscit = $arrDatos;
				$datos->codigoRespuesta = 1;
			}
			$conexion = null;		
			return $datos;
		}
	}


 ?>