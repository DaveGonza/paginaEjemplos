<!DOCTYPE html>
<html>
<head>
	<title>Productos</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../css/pagina.css">
	<!--Archivo JavaScript-->
	<script type="text/javascript" src = "../css/librerias/DateTimePicker/js/jquery.datetimepicker.full.min.js"></script>
	<script src="../js/paginaejemplo.js"></script>
	<style type="text/css">
	body 
	{
		background-image: url("../imagenes/fondo.jpg");
		background-repeat: no-repeat;
		background-attachment: fixed;  
	  	background-size: 100% 100%;
	}
</style>
</head>
<body>
	<div>
		<ul>
			<li><a href="../index.html">Home</a></li>
			<li><a class="active" href="ViewProductos.php">Productos</a></li>
			<li><a href="ViewFormulario.php">Formulario</a></li>
		</ul>		
	</div>
			<!--********************************************************ENCABEZADO DEL GRID****************************************************************************-->
		<br>
		<div class="col-sm-1" >
				<button class= "btn btn-sm btn-primary" id="btnBuscar" multiple> <i class="glyphicon glyphicon-search" ></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Buscar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
		</div>
			<div class="col-sm-1" >
				<button class= "btn btn-sm btn-primary" id="btnEliminar" multiple> <i class="glyphicon glyphicon-trash" ></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Eliminar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
		</div>
			<div class="col-sm-1" >
		<a href="ViewFormulario.php" class= "btn btn-sm btn-primary" id="btnModificar" role="button"multiple> <i class="glyphicon glyphicon-plus" ></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Modificar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
		</div>
		</div>
			<div class="col-sm-1" >
				<a href="ViewFormulario.php" class= "btn btn-sm btn-primary" id="btnInsertar" role="button"multiple> <i class="glyphicon glyphicon-plus" ></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Insertar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
		</div>
		<br>
		<br>
		<div class = "col-sm-12" >
			<div id = "divDetalle" class = "panel panel-primary" >
				<div id = "divDetalle-Contenido">
					<div class = "form-group">															
						<div id = "divGrid" class = "panel-body" role = "grid" style = "overflow: auto; height:425px;">
							<table id = "tbGridTable" class = "table table-striped table-condensed table-bordered table-hover" >
								<thead>
									<tr align = "center">
										<th class="center" width="1%"><input type="checkbox" id="ckTodos" name="allCheckBox" value="all" ></th>
										<th class = "center tdLargo" width = "110px">Nombre</th>
										<th class = "center tdLargo" width = "160px">Apellido Paterno</th>
										<th class = "center tdLargo" width = "120px">Apellido Materno</th>
										<th class = "center tdLargo" width = "150px">Fecha De Nacimiento</th>			
										<th class = "center tdLargo" width = "180px">Direccion</th>
										<th class = "center tdLargo" width = "110px">Telefono</th>
										<th class = "center tdLargo" width = "160px">Estado Civil</th>
										<th class = "center tdLargo" width = "120px">CURP</th>
										<th class = "center tdLargo" width = "150px">RFC</th>
										<th class = "center tdLargo" width = "150px">NSS</th>
										<th class = "center tdLargo" width = "150px">Nivel De Estudio</th>
									</tr>
								</thead>
								<tbody id = "cuerpo">
									<!-- Se agregan los registros    -->
								</tbody>
							</table>
						</div>
					</div>
				</div>	
			</div>
		</div>
</body>
</html>