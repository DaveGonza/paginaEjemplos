$(document).ready(function()
{	
	//Ejemplo de como se Desabilitan los botones
	//$("#BtnGuardarpr").prop("disabled",true);
	//$("#BtnModificarpr").prop("disabled",true);
	//$("#BtnGuardarau").prop("disabled",true);
	//$("#BtnModificarau").prop("disabled",true);
	
$('#FechaNacimiento ').datetimepicker(
{
	format:'d/m/Y',
	defaultTime:false,
	inline:false,
	timepicker:false,
	maxDate:hoyFecha().toString()

	
});
$.datetimepicker.setLocale('es');

$('#BtnGuardarpr ').click(function()
{
	camposllenos();
});

$('#btnBuscar ').click(function()
{
	BuscarDatosPersonales();
});

$('#btnEliminar ').click(function()
{
	EliminarDatosPersonales();
	refrescar();
});
$('#btnModificar ').click(function()
{
	
});
$('#btnInsertar ').click(function()
{
	
});


$("#ckTodos").change(function () 
{
	$("input:checkbox").prop('checked', $(this).prop("checked"));
});

});// Termina ready


function camposllenos()
{
	if ($('#Nombre').val()!='')
	{
		if ($('#ApPaterno').val()!='') 
		{
			if ($('#ApMaterno').val()!='') 
			{
				if ($('#FechaNacimiento').val()!='') 
				{
					if ($('#Direccion').val()!='') 
					{	
						if ($('#Telefono').val()!='') 
						{
							if ($('#EsCivil').val()!='') 
							{
								if ($('#CURP').val()!='') 
								{
									if ($('#RFC').val()!='')
									{
										if ($('#NSS').val()!='') 
										{
											if ($('#NivelEstudio').val()!='')
											{
												alert("estan llenos");
											}
											else
											{
												alert("Falta Nivel de Estudio");
											}
										}
										else
										{
											alert("Falta NSS");
										}
									} 
									else
									{
										alert("Falta RFC");
									}
								}
								else
								{
									alert("Falta CURP");
								}
							}
							else
							{
								alert("Falta EsCivil");
							}								
						}
						else
						{
							alert("Falta Telefono");
						}
					}
					else
					{
						alert("Falta Direccion");
					}
				}
				else
				{
					alert("Falta Fecha de Nacimiento");
				}
			}
			else
			{
				alert("Falta Apellido Materno");
			}
		}
		else
		{
			alert("Falta ApPaterno");
		}
	}
	else
	{
		alert("Falta Nombre");
	}

}
//Obtener la fecha de la pagina
function addZero(i)
{
    if (i < 10) {
        i = '0' + i;
    }
    return i;
}
function hoyFecha()
{
	
    var hoy = new Date();
    var dia = hoy.getDay();
    var dd = hoy.getDate();
    var mm = hoy.getMonth()+1;
    var yyyy = hoy.getFullYear();
    
    dd = addZero(dd);
    mm = addZero(mm);
 
    return dia[hoy.getDay()] + ',' + dd + ' de '+ mm[hoy.getMonth()]+ ' del '+yyyy;	
}

function BuscarDatosPersonales()
{
	
	// se limpia grid
	var Table = document.getElementById("cuerpo");
	Table.innerHTML = "";
	iRowsPrevio = 0;
	
	funcionAjax=$.ajax(
		{	
			url: "ConexionEnruter.php",
			type: "POST",
			async: false,
			dataType: "json",
			data: 
				{	iOpcion: 2
				},
			 success: function(data)
			 {
		 		if (data.datoscit != '') 
		 		{		 		
		 			for (var i = 0; i < data.datoscit.nombre.length; i++) 
					{
						$("#cuerpo").append(
							"<tr class=''>"+
							"<td  class='center' width=''>"+
							"<span><input  id='c" + iRowsPrevio + "01' type='checkbox' value='"+i+"'></span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span id='c" + iRowsPrevio + "02'>"+ data.datoscit.nombre[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span id='c" + iRowsPrevio + "03'>"+ data.datoscit.apellido_paterno[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span id='c" + iRowsPrevio + "04'>"+ data.datoscit.apellido_materno[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span  id='c" + iRowsPrevio + "05'>"+ data.datoscit.fechanacimineto[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span id='c" + iRowsPrevio + "06'>"+ data.datoscit.direccion[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span  id='c" + iRowsPrevio + "07'>"+ data.datoscit.telefono[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span  id='c" + iRowsPrevio + "08'>"+ data.datoscit.estadocivil[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span  id='c" + iRowsPrevio + "09'>"+ data.datoscit.curp[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span id='c" + iRowsPrevio + "10'>"+ data.datoscit.rfc[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span id='c" + iRowsPrevio + "11'>"+ data.datoscit.nss[i] +"</span>"+
							"</td>"+
							"<td  class='center' width=''>"+
							"<span id='c" + iRowsPrevio + "11'>"+ data.datoscit.nivelEstudio[i] +"</span>"+
							"</td>"+
						"</tr>" );
						iRowsPrevio++;
	 				}

		 		}
		 		else 
		 		{
		 			alert("NO SE ENCONTRARON REGISTROS PARA MOSTRAR.");
		 		} 	
			}
		}
	);
}//Termina getBuscarDatos(param1,param2);

function EliminarDatosPersonales(nombre)
{
	var iTotalRegActualizar = 0;
 	$("input:checkbox:checked").each(function() 
	{
		if($(this).attr('id') != 'ckTodos')
		{
		 	iTotalRegActualizar++;
		 	var sId = $(this).attr('id');
			var sRow = sId.replace('c', '').substring(0, sId.length - 3);
			var nombre = $("#c" + sRow + "02").text();
			$.ajax(
			{	
				url: "ConexionEnruter.php",
				type: "POST",
				async: false,
				dataType: "json",
				data: 
					{	iOpcion: 3,
						nombre:nombre
					},
				 success: function(data)
				 {
			 		if (data.codigoRespuesta == 1) 
			    	{
			    		alert("Exito")
			    	} 
			    	else 
			    	{
			    		alert("Error respuesta")
			    	}
				}
			});
		}
	});
}

function refrescar()
{
	location.reload(true)
}


function EditarDatosPersonales(nombre)
{
	var iTotalRegActualizar = 0;
 	$("input:checkbox:checked").each(function() 
	{
		if($(this).attr('id') != 'ckTodos')
		{
		 	iTotalRegActualizar++;
		 	var sId = $(this).attr('id');
			var sRow = sId.replace('c', '').substring(0, sId.length - 3);
			var nombre = $("#c" + sRow + "02").text();
			$.ajax(
			{	
				url: "ConexionEnruter.php",
				type: "POST",
				async: false,
				dataType: "json",
				data: 
					{	iOpcion: 4,
						nombre:nombre
					},
				 success: function(data)
				 {
			 		if (data.codigoRespuesta == 1) 
			    	{
			    		//Datos a ditar
			    		if (data.datoscit != '') 
				 		{		 		
				 			for (var i = 0; i < data.datoscit.nombre.length; i++) 
							{
								//insertar a l formulario
							}
						}
			    	} 
			    	else 
			    	{
			    		alert("Error respuesta")
			    	}
				}
			});
		}
	});
}